package com.zszzs.companyvue.controller;

import com.alibaba.fastjson.JSON;
import com.zszzs.companyvue.common.Result;
import com.zszzs.companyvue.entity.Stock;
import com.zszzs.companyvue.entity.StockDto;
import com.zszzs.companyvue.mapper.StockMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 25951
 * @version 1.0
 * @date 2023-09-12 9:01
 */
@RestController
@CrossOrigin
@RequestMapping
public class StockController {

    @Autowired
    StockMapper stockMapper;


    @GetMapping("/fund")
    public Result fundAll(@RequestParam(value = "sortField", defaultValue = "unitNetVal") String sortField, @RequestParam String sortDirection, @RequestParam Integer pageNum, @RequestParam Integer pageSize) {

        List<Stock> stocks = stockMapper.fundAll(sortField, sortDirection, pageNum, pageSize);
        List<StockDto> stockDtos = JSON.parseArray(JSON.toJSONString(stocks), StockDto.class);
        LocalDate currentDate = LocalDate.of(2015, 9, 7);
        LocalDate date = currentDate.minus(1, ChronoUnit.WEEKS);
        LocalDate dateMouth = currentDate.minus(1, ChronoUnit.MONTHS);
        LocalDate dateThreeMouth = currentDate.minus(3, ChronoUnit.MONTHS);
        LocalDate dateYear = currentDate.minus(1, ChronoUnit.YEARS);
        LocalDate dateTwoYear = currentDate.minus(2, ChronoUnit.YEARS);
        LocalDate dateThreeYear = currentDate.minus(3, ChronoUnit.YEARS);
        for (StockDto s : stockDtos){
            s.setStatisticsDate(Date.valueOf(currentDate));
            s.setVal(stockMapper.fundInfo(s.getFundCode(),Date.valueOf(currentDate)));
        }

        //七日
        for (StockDto s : stockDtos) {
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setWeekInfo(0f);
                continue;
            }

            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(date));
            while (previousNetWorth == null) {
                date = date.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(date));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setWeekInfo(0f);
            } else {
                s.setWeekInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }
        //一个月
        for (StockDto s : stockDtos) {
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setMonthInfo(0f);
                continue;
            }

            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateMouth));
            while (previousNetWorth == null) {
                dateMouth = dateMouth.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateMouth));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setMonthInfo(0f);
            } else {
                s.setMonthInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }
        //三个月
        for (StockDto s : stockDtos) {
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setThreeMonthInfo(0f);
                continue;
            }

            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateThreeMouth));
            while (previousNetWorth == null) {
                dateThreeMouth = dateThreeMouth.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateThreeMouth));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setThreeMonthInfo(0f);
            } else {
                s.setThreeMonthInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }
//        //一个月
//        for (StockDto s :stockDtos){
//            Double currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
//            if (currentNetWorth == null) {
//                s.setWeekInfo(0.0);
//                continue;
//            }
//
//            Double previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(date));
//            while (previousNetWorth == null){
//                dateMouth = dateMouth.plus(1,ChronoUnit.DAYS);
//                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(date));
//                if (previousNetWorth == null)
//                    break;
//            }
//
//            if (previousNetWorth == null){
//                s.setWeekInfo(0.0);
//            }else {
//                s.setWeekInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
//            }
//
//        }
        //一年
        for (StockDto s : stockDtos) {
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setYearInfo(0f);
                continue;
            }

            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateYear));
            while (previousNetWorth == null) {
                dateYear = dateYear.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateYear));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setYearInfo(0f);
            } else {
                s.setYearInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }
        //两年
        for (StockDto s : stockDtos) {
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setTwoYearInfo(0f);
                continue;
            }

            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateTwoYear));
            while (previousNetWorth == null) {
                dateTwoYear = dateTwoYear.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateTwoYear));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setTwoYearInfo(0f);
            } else {
                s.setTwoYearInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }
        //近三年
        for (StockDto s : stockDtos) {
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setThreeYearInfo(0f);
                continue;
            }

            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateThreeYear));
            while (previousNetWorth == null) {
                dateThreeYear = dateThreeYear.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(dateThreeYear));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setThreeYearInfo(0f);
            } else {
                s.setThreeYearInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }
        //今年
        for (StockDto s : stockDtos) {
            LocalDate nowDate = LocalDate.now();
            LocalDate with = nowDate.with(TemporalAdjusters.firstDayOfYear());
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setThisYearInfo(0f);
                continue;
            }

            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(with));
            while (previousNetWorth == null) {
                with = with.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(with));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setThisYearInfo(0f);
            } else {
                s.setThisYearInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }

        //今年
        for (StockDto s : stockDtos) {
            Float currentNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(currentDate));
            if (currentNetWorth == null) {
                s.setOldYearInfo(0f);
                continue;
            }
            Date fundDate = stockMapper.fundDate(s.getFundCode());
            LocalDate localDate = fundDate.toLocalDate() ;
            Float previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(localDate));
            while (previousNetWorth == null) {
                localDate = localDate.plus(1, ChronoUnit.DAYS);
                previousNetWorth = stockMapper.fundInfo(s.getFundCode(), Date.valueOf(localDate));
                if (previousNetWorth == null)
                    break;
            }

            if (previousNetWorth == null) {
                s.setOldYearInfo(0f);
            } else {
                s.setOldYearInfo((currentNetWorth - previousNetWorth) * 100 / previousNetWorth);
            }

        }
        for (StockDto s: stockDtos){
            if (s.getVal() == null){
                s.setVal(0f);
            }
        }

        Map<String,Object> map = new HashMap<>();
        Integer total = stockMapper.fundTotal();

        map.put("stock", stockDtos);
        map.put("total",total );

        return Result.success(map);
    }
}