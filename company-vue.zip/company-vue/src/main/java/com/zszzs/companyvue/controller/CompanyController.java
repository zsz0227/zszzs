package com.zszzs.companyvue.controller;

import com.zszzs.companyvue.common.Result;
import com.zszzs.companyvue.entity.Company;
import com.zszzs.companyvue.mapper.CompanyMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author 25951
 * @version 1.0
 * @date 2023-09-10 11:30
 */
@RestController
    @RequestMapping("/companies")
@CrossOrigin
@Slf4j
public class CompanyController  {


    @Autowired
    private CompanyMapper companyMapper;

    @GetMapping("")
    public Result selectAll() {
        List<Company> users = companyMapper.selectAll();
        return Result.success(users);
    }

    @GetMapping("/{comId}")
    public Result selectCompany(@PathVariable Long comId){
        List<Company> companies = companyMapper.selectCompany(comId);


        return Result.success(companies);
    }



    @PostMapping()
    public Result save(@RequestBody Company company){

        companyMapper.save(company);

        return Result.success();
    }

    @PutMapping("/{comId}")
    public Result update(@RequestBody Company company){
        companyMapper.update(company);

        return Result.success();
    }

    @DeleteMapping("/{comId}")
    public Result delete(@PathVariable Long comId){

        companyMapper.delete(comId);

        return Result.success();
    }

}
