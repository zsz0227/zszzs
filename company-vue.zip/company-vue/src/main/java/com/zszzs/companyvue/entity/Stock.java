package com.zszzs.companyvue.entity;

import lombok.Data;

import java.sql.Date;

/**
 * @author 25951
 * @version 1.0
 * @date 2023-09-12 8:58
 */
@Data
public class Stock {
    private Integer fundCode;

    private String fundShortName;

    private Date endDate;

    private Float unitNetVal;

}
