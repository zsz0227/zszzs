package com.zszzs.companyvue.entity;

import lombok.Data;

import java.sql.Date;

/**
 * @author 25951
 * @version 1.0
 * @date 2023-09-10 11:21
 */
@Data
public class Company {
    private Long orgUniCode;

    private String orgChiName;

    private String induSmaPar;

    private String orgDele;

    private Float regCap;

    private Date orgEstDate;

}
