package com.zszzs.companyvue.mapper;

import com.zszzs.companyvue.entity.Company;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author 25951
 * @version 1.0
 * @date 2023-09-10 11:27
 */
@Mapper
public interface CompanyMapper  {

    @Select("select * from companyinfo order by orgEstDate desc ")
    List<Company> selectAll();

    @Select("select * from companyinfo where orgUniCode like concat('%',#{comId},'%') order by orgEstDate desc")
    List<Company> selectCompany(@Param("comId") Long comId);

    @Insert("insert into companyinfo (orgChiName, induSmaPar, orgDele, regCap, orgEstDate) " +
            "values (#{orgChiName},#{induSmaPar},#{orgDele},#{regCap},#{orgEstDate})")
    void save(Company company);

    @Update("update companyinfo set orgChiName = #{orgChiName}, induSmaPar = #{induSmaPar}," +
            "orgDele = #{orgDele},regCap = #{regCap},orgEstDate = #{orgEstDate} where orgUniCode = #{orgUniCode}")
    void update(Company company);

    @Delete("delete from companyinfo where orgUniCode = #{orgUniCode}")
    void delete(Long orgUniCode);

}
