package com.zszzs.companyvue.common;

import lombok.Data;

/**
 * Controller 统一返回的包装类
 * @author 25951
 * @version 1.0
 * @date 2023-09-07 16:40
 */
@Data
public class Result {

    private static final String SUCCESS_CODE = "200";
    private static final String ERROR_CODE = "500";

    private String code; //返回的状态码，告诉前端是否成功

    private String msg;//错误信息

    private Object data;//包装的数据

    public Result(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public Result() {
    }

    public Result(String code, String msg, Object data) {
        this.code = code;
        this.msg = msg;
        this.data = data;
    }


    public static Result success(Object data){
        return new Result(SUCCESS_CODE,"",data);
    }

    public static Result success(){
        return new Result(SUCCESS_CODE,"");
    }

    public static Result error(String msg){
        return new Result(ERROR_CODE,msg);
    }
}
