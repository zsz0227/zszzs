package com.zszzs.companyvue.entity;

import lombok.Data;

import java.sql.Date;

/**
 * @author 25951
 * @version 1.0
 * @date 2023-09-12 13:28
 */
@Data
public class StockDto {
    private Integer fundCode;

    private String fundShortName;

    private Date endDate;

    private Float unitNetVal;

    private Date statisticsDate;

    private Float val;

    private Float weekInfo;

    private Float monthInfo;

    private Float threeMonthInfo;

    private Float yearInfo;

    private Float twoYearInfo;

    private Float threeYearInfo;

    private Float thisYearInfo;

    private Float oldYearInfo;

}
