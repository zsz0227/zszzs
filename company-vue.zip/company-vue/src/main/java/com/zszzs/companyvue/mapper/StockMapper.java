package com.zszzs.companyvue.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zszzs.companyvue.entity.Stock;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.sql.Date;
import java.util.List;

/**
 * @author 25951
 * @version 1.0
 * @date 2023-09-12 9:00
 */
@Mapper
public interface StockMapper extends BaseMapper<Stock> {

    @Select("select distinct fundCode,fundShortName from companystock order by  ${sortField} ${sortDirection} limit #{pageNum},#{pageSize}")
    List<Stock> fundAll(@Param("sortField") String sortField, @Param("sortDirection") String sortDirection,
                        @Param("pageNum") Integer pageNum, @Param("pageSize") Integer pageSize);

    @Select("select unitNetVal from companystock where fundCode = #{fundCode} and endDate = #{date}")
    Float fundInfo(@Param("fundCode") Integer fundCode, @Param("date") Date date);

    @Select("select endDate from companystock where fundCode = #{fundCode} order by endDate desc limit 0,1")
    Date fundDate(@Param("fundCode")  Integer fundCode);


    @Select("select count(*) from (select distinct fundCode,fundShortName from companystock) b ")
    Integer fundTotal();

}
