package com.zszzs.companyvue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompanyVueApplicationTests {

    @Test
    void contextLoads() {
    }

}
